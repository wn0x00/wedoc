# -*- coding: utf-8 -*-
"""
    :Author: woni
    :Date: 2023-01-18 14:42:16
    :Last Modified by:   woni
    :Last Modified time: 2023-01-18 14:42:16
"""

from wedoc.api.base import WedocApiBase


class Form(WedocApiBase):
    def create_form(self):
        pass

    def get_form(self):
        pass

    def get_form_info(self):
        pass

    def get_form_answer(self):
        pass

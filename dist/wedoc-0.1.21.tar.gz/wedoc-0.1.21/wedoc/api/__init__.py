from wedoc.api.document import Document
from wedoc.api.spreadsheet import Spreadsheet
from wedoc.api.form import Form
